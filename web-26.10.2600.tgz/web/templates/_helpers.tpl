{{/* vim: set filetype=mustache: */}}
{{/*
Expand the name of the chart.
*/}}
{{- define "web.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "web.fullname" -}}
{{- if .Values.fullnameOverride -}}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- $name := default .Chart.Name .Values.nameOverride -}}
{{- if contains $name .Release.Name -}}
{{- .Release.Name | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" -}}
{{- end -}}
{{- end -}}
{{- end -}}

{{/*
The headless Service that Tomcat's DNSMembershipProvider resolves to find replication peers.

Defined once because two templates need it and they must agree exactly: service-headless.yaml
creates it, and configmap.yaml hands the name to the pods. If the two ever derived it differently
the mismatch would not fail anything -- DNSMembershipProvider only warns on an unresolvable name --
and every pod would quietly run a one-member cluster, replicating nothing.

Deliberately not truncated beyond what web.fullname already does: adding a length guard here would
rename the Service for long release names, which is a rename of an existing object rather than a
fix.
*/}}
{{- define "web.headlessServiceName" -}}
{{- printf "%s-headless" (include "web.fullname" .) -}}
{{- end -}}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "web.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
Common labels
*/}}
{{- define "web.labels" -}}
helm.sh/chart: {{ include "web.chart" . }}
app.kubernetes.io/part-of: bluestep
{{ include "web.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end -}}

{{/*
Selector labels
*/}}
{{- define "web.selectorLabels" -}}
app.kubernetes.io/name: {{ include "web.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end -}}

{{/*
Create the name of the service account to use
*/}}
{{- define "web.serviceAccountName" -}}
{{- if .Values.serviceAccount.create -}}
    {{ default (include "web.fullname" .) .Values.serviceAccount.name }}
{{- else -}}
    {{ default "default" .Values.serviceAccount.name }}
{{- end -}}
{{- end -}}

{{/*
Name of the marker key External Secrets writes into the target Secret once it has reconciled
this exact ExternalSecret spec. The name carries a hash of the spec Helm renders, so the
secrets volume, whose items name the key, cannot mount for a pod while the Secret still
holds what ESO synced from an older spec -- a remapped key that already exists would otherwise pass.
A value changed only in BWS leaves the spec, and so the name, unchanged.
*/}}
{{- define "web.esoSyncedKey" -}}
B6P_ESO_SYNCED_{{ dict "store" .Values.externalSecrets.secretStoreRef "data" .Values.externalSecrets.data | toJson | sha256sum | trunc 12 }}
{{- end -}}

{{/*
volumeMounts for a container that runs a JVM: the trust files the jvm-security init container built
(see the jvm-security values block). The emptyDir whole at /etc/bluestep/jvm-security, for the
validated java.security that JDK_JAVA_OPTIONS names, and its cacerts and blocked.certs over the JDK's
own by subPath. subPath never sees a volume update, which is safe here: the emptyDir is written once,
before any of these containers start, and a changed ConfigMap reaches the pods by rolling them
(Reloader, or the checksum on a Helm upgrade). The ConfigMap itself is never mounted here, so a
JVM only ever reads what the init container validated. Include it only when jvmSecurity.enabled.
*/}}
{{- define "web.jvmSecurityMounts" -}}
{{- $lib := printf "%s/lib/security" .Values.jvmSecurity.javaHome -}}
- name: jvm-security-merged
  mountPath: /etc/bluestep/jvm-security
  readOnly: true
- name: jvm-security-merged
  mountPath: {{ printf "%s/blocked.certs" $lib | quote }}
  subPath: blocked.certs
  readOnly: true
- name: jvm-security-merged
  mountPath: {{ printf "%s/cacerts" $lib | quote }}
  subPath: cacerts
  readOnly: true
{{- end -}}

{{/*
Points every JVM the `java` launcher starts in the container (bin/start, runclass) at the validated
java.security, layered over the JDK's own file (one '='; '==' would replace it). JDK_JAVA_OPTIONS
rather than the chart's JAVA_TOOL_OPTIONS: that string is the app's own, and runclass cuts it at
-agentlib:jdwp when debugging is on, which would take this flag with it. Set as an explicit env var,
so it also wins over a JDK_JAVA_OPTIONS key in configmap.data. Include it only when
jvmSecurity.enabled.
*/}}
{{- define "web.jvmSecurityEnv" -}}
- name: JDK_JAVA_OPTIONS
  value: "-Djava.security.properties=/etc/bluestep/jvm-security/java.security"
{{- end -}}

{{/*
The jvm-security ConfigMap names: the chart's (<fullname>-jvm-security) and the operator's overlay
(<fullname>-jvm-security-local). The fullname is cut to leave room for the longer suffix before
either is appended, and both share that cut, so the pair stays distinct and recognisable at any
length. Truncating after appending would instead eat the suffix, and the two names could collapse
into one. A fullname of 44 characters or fewer is unaffected.
*/}}
{{- define "web.jvmSecurityBase" -}}
{{- include "web.fullname" . | trunc (sub 63 (len "-jvm-security-local") | int) | trimSuffix "-" -}}
{{- end -}}
{{- define "web.jvmSecurityName" -}}
{{- printf "%s-jvm-security" (include "web.jvmSecurityBase" .) -}}
{{- end -}}
{{- define "web.jvmSecurityLocalName" -}}
{{- printf "%s-jvm-security-local" (include "web.jvmSecurityBase" .) -}}
{{- end -}}
