{{/*
Expand the name of the chart.
*/}}
{{- define "gateway.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
*/}}
{{- define "gateway.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "gateway.labels" -}}
helm.sh/chart: {{ include "gateway.name" . }}-{{ .Chart.Version | replace "+" "_" }}
{{ include "gateway.selectorLabels" . }}
app.kubernetes.io/version: {{ .Values.image.tag | default .Chart.AppVersion | quote }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "gateway.selectorLabels" -}}
app.kubernetes.io/name: {{ include "gateway.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Container image
*/}}
{{- define "gateway.image" -}}
{{- printf "%s:%s" .Values.image.repository (.Values.image.tag | default .Chart.AppVersion) }}
{{- end }}

{{/*
JVM trust settings (jvmSecurity in values.yaml). The Deployment is this chart's only workload and
takes the helpers below.

Every lookup goes through `.Values.jvmSecurity | default dict`, so a release upgraded with --reuse-values
from a chart that had no jvmSecurity block renders as disabled -- exactly as before -- instead of failing.
*/}}
{{- define "gateway.jvmSecurity.enabled" -}}
{{- if (.Values.jvmSecurity | default dict).enabled }}true{{ end }}
{{- end }}

{{/*
The two ConfigMap names. The fullname is cut first, leaving room for the longer suffix, so a long
fullname still yields two distinct names of at most 63 characters. Cutting after appending would eat
the suffix and could make both names the same.
*/}}
{{- define "gateway.jvmSecurityNameBase" -}}
{{- include "gateway.fullname" . | trunc (sub 63 (len "-jvm-security-local") | int) | trimSuffix "-" }}
{{- end }}

{{- define "gateway.jvmSecurityName" -}}
{{- printf "%s-jvm-security" (include "gateway.jvmSecurityNameBase" .) }}
{{- end }}

{{- define "gateway.jvmSecurityLocalName" -}}
{{- printf "%s-jvm-security-local" (include "gateway.jvmSecurityNameBase" .) }}
{{- end }}

{{/*
First init container. files/jvm-security-init.sh (kept byte-identical to the campaign's script) guards
java.home, normalises and validates both fingerprint lists, and builds the snapshot the JVM containers
read from the jvm-security-merged emptyDir, merging in the operator's optional -local overlay: blocked.certs (the JDK's list, then ours), cacerts (the
image's own store minus every distrusted anchor) and a validated copy of java.security. The app never
reads the ConfigMap itself, so an in-cluster edit reaches it only through a restart that re-runs this.
No envFrom: it must not pick up the app's settings.
*/}}
{{- define "gateway.jvmSecurity.initContainer" -}}
{{- $js := .Values.jvmSecurity | default dict }}
- name: jvm-security
  image: {{ include "gateway.image" . }}
  imagePullPolicy: {{ .Values.image.pullPolicy }}
  command: ["sh", "-ec"]
  args:
    - |
      {{- .Files.Get "files/jvm-security-init.sh" | nindent 6 }}
  env:
    - name: EXPECTED_JAVA_HOME
      value: {{ $js.javaHome | quote }}
  volumeMounts:
    - mountPath: /etc/bluestep/jvm-security-src
      name: jvm-security
      readOnly: true
    - mountPath: /etc/bluestep/jvm-security-local
      name: jvm-security-local
      readOnly: true
    - mountPath: /merged
      name: jvm-security-merged
  securityContext:
    runAsNonRoot: true
    readOnlyRootFilesystem: true
    allowPrivilegeEscalation: false
    capabilities:
      drop: [ALL]
  resources:
    {{- toYaml $js.initResources | nindent 4 }}
{{- end }}

{{/*
Mounts for every container that runs a JVM: the init container's snapshot, never the ConfigMap. The two
subPath mounts lay the merged blocked.certs and the pruned cacerts over the JDK's own. A subPath mount is
never updated in place -- fine, because a change rolls the pod (checksum annotation on a helm upgrade,
Reloader on an edit to the ConfigMap) and the init container rebuilds the snapshot.
*/}}
{{- define "gateway.jvmSecurity.volumeMounts" -}}
{{- $js := .Values.jvmSecurity | default dict }}
- mountPath: /etc/bluestep/jvm-security
  name: jvm-security-merged
  readOnly: true
- mountPath: {{ printf "%s/lib/security/blocked.certs" $js.javaHome }}
  name: jvm-security-merged
  subPath: blocked.certs
  readOnly: true
- mountPath: {{ printf "%s/lib/security/cacerts" $js.javaHome }}
  name: jvm-security-merged
  subPath: cacerts
  readOnly: true
{{- end }}

{{- define "gateway.jvmSecurity.volumes" -}}
- name: jvm-security
  configMap:
    name: {{ include "gateway.jvmSecurityName" . }}
# The operator's overlay (see the values comment above jvmSecurity). Helm never renders it, so an
# emergency edit there survives deploys; optional, so a namespace without one starts as usual.
- name: jvm-security-local
  configMap:
    name: {{ include "gateway.jvmSecurityLocalName" . }}
    optional: true
- name: jvm-security-merged
  emptyDir:
    sizeLimit: 2Mi
{{- end }}

{{/*
Single "=": the validated copy layers over the JDK's java.security instead of replacing it.
JDK_JAVA_OPTIONS, not JAVA_TOOL_OPTIONS: the image starts the JVM with the java launcher, which reads it,
and JAVA_TOOL_OPTIONS stays free for whatever else sets it.
*/}}
{{- define "gateway.jvmSecurity.env" -}}
- name: JDK_JAVA_OPTIONS
  value: "-Djava.security.properties=/etc/bluestep/jvm-security/java.security"
{{- end }}

{{/*
Whether the git proxy is on (git in values.yaml). Every lookup goes through `.Values.git | default dict`, as the
Hazelcast and jvmSecurity helpers do, so a release upgraded with --reuse-values from a chart without the git block
renders as disabled instead of failing on a nil pointer.
*/}}
{{- define "gateway.git.enabled" -}}
{{- if (.Values.git | default dict).enabled }}true{{ end }}
{{- end }}

{{/*
The keys of the gateway's Secret, as <key in the pod>: <remote key in the store>: eso.data, plus git.eso.data while
the git proxy is on (its forge password). One map renders both the ExternalSecret and the secrets volume's items, so
the startup gate covers exactly what ESO writes, and a gateway with the proxy off never waits on forge keys.
*/}}
{{- define "gateway.secretData" -}}
{{- $data := deepCopy .Values.eso.data -}}
{{- if include "gateway.git.enabled" . -}}
{{- $data = merge $data (deepCopy .Values.git.eso.data) -}}
{{- end -}}
{{- if include "gateway.auth.enabled" . -}}
{{- $data = merge $data (deepCopy (((.Values.auth | default dict).eso | default dict).data | default dict)) -}}
{{- end -}}
{{- if include "gateway.sso.enabled" . -}}
{{- $data = merge $data (deepCopy ((((.Values.auth | default dict).sso | default dict).eso | default dict).data | default dict)) -}}
{{- end -}}
{{- toYaml $data -}}
{{- end -}}

{{/* The inline Secret's values (eso.enabled false): secrets, plus git.secrets while the git proxy is on. */}}
{{- define "gateway.inlineSecrets" -}}
{{- $data := deepCopy .Values.secrets -}}
{{- if include "gateway.git.enabled" . -}}
{{- $data = merge $data (deepCopy .Values.git.secrets) -}}
{{- end -}}
{{- if include "gateway.auth.enabled" . -}}
{{- $data = merge $data (deepCopy ((.Values.auth | default dict).secrets | default dict)) -}}
{{- end -}}
{{- if include "gateway.sso.enabled" . -}}
{{- $data = merge $data (deepCopy (((.Values.auth | default dict).sso | default dict).secrets | default dict)) -}}
{{- end -}}
{{- toYaml $data -}}
{{- end -}}

{{/*
Whether browser sign-in is on (auth in values.yaml), refused without Hazelcast: sessions, the lockout and the code
caps live there. Read through `default dict` so a release upgraded with --reuse-values from a chart without the auth
block renders as disabled.

Refused, too, above one replica (R82 P3-4, ruling Q6 "ship on 1 replica"): the emailed codes live in the pod's own
memory (InMemoryEmailCodes), so on two pods about half of all code entries and resends land on the pod without the
code and answer 410 code-expired. Remove this guard when the shared code store lands (the before-2-replicas list).
*/}}
{{- define "gateway.auth.enabled" -}}
{{- if (.Values.auth | default dict).enabled }}
{{- if not (include "gateway.hazelcast.enabled" .) }}
{{- fail "auth.enabled needs hazelcast.enabled: browser sessions, the sign-in lockout and the code caps live on the gateway's Hazelcast" }}
{{- end }}
{{- if and (include "gateway.auth.password" .) (gt (int .Values.replicaCount) 1) }}
{{- fail "auth.enabled needs replicaCount 1: sign-in codes are kept in the pod's own memory (no shared code store yet), so a second replica would answer about half of all code entries 410 code-expired (password sign-in, auth.smtp.host, only: single sign-on alone runs on any number)" }}
{{- end }}
{{- if not (or (include "gateway.auth.password" .) (((.Values.auth | default dict).sso | default dict).enabled)) }}
{{- fail "auth.enabled needs auth.smtp.host (password sign-in) or auth.sso.enabled (single sign-on): with neither, nobody can sign in" }}
{{- end }}true
{{- end }}
{{- end }}

{{/*
Whether password sign-in is on (SSO1): a mailer is configured (auth.smtp.host set). Without one the gateway refuses
password sign-in and offers single sign-on only, so the mailer's values, the remember-device key and the one-replica
guard apply only while this is true. Plain read, no checks: gateway.auth.enabled makes them.
*/}}
{{- define "gateway.auth.password" -}}
{{- if (((.Values.auth | default dict).smtp | default dict).host) }}true{{ end }}
{{- end }}

{{/*
Whether sign-in with Microsoft is on (SSO1): auth.enabled and auth.sso.enabled, with at least one provider on.
*/}}
{{- define "gateway.sso.enabled" -}}
{{- $sso := ((.Values.auth | default dict).sso | default dict) -}}
{{- if and (include "gateway.auth.enabled" .) $sso.enabled -}}
{{- if not (($sso.microsoft | default dict).enabled) -}}
{{- fail "auth.sso.enabled needs a provider: auth.sso.microsoft.enabled (the only one built)" -}}
{{- end -}}true
{{- end -}}
{{- end -}}

{{/*
Browser sign-in refuses to start without its remember-device key (GATEWAY_DEVICE_TRUST_KEY, >= 32 bytes), so the
render refuses first: with ESO the key must be named in auth.eso.data (the value lives in the store, never here);
inline (local clusters) auth.secrets must hold one of at least 32 bytes. Renders nothing; included only while
auth.enabled, so a chart with sign-in off renders exactly as before.
*/}}
{{- define "gateway.auth.deviceTrustKeyRequired" -}}
{{- $auth := .Values.auth | default dict -}}
{{- if .Values.eso.enabled -}}
{{- if not (hasKey (($auth.eso | default dict).data | default dict) "GATEWAY_DEVICE_TRUST_KEY") -}}
{{- fail "auth.enabled needs auth.eso.data.GATEWAY_DEVICE_TRUST_KEY: the remember-device key (>= 32 bytes, one per cluster) from the secret store" -}}
{{- end -}}
{{- else -}}
{{- if lt (len (toString (index ($auth.secrets | default dict) "GATEWAY_DEVICE_TRUST_KEY" | default ""))) 32 -}}
{{- fail "auth.enabled needs auth.secrets.GATEWAY_DEVICE_TRUST_KEY of at least 32 bytes: the remember-device key" -}}
{{- end -}}
{{- end -}}
{{- end -}}

{{/*
The gateway's own Hazelcast cluster (hazelcast in values.yaml). Every lookup goes through `.Values.hazelcast | default
dict`, so a release upgraded with --reuse-values from a chart without the block renders as disabled.
*/}}
{{- define "gateway.hazelcast.enabled" -}}
{{- if (.Values.hazelcast | default dict).enabled }}true{{ end }}
{{- end }}

{{/* Headless Service for Hazelcast Kubernetes DNS discovery; the fullname is cut to leave room for the suffix. */}}
{{- define "gateway.hazelcastServiceName" -}}
{{- printf "%s-hazelcast" (include "gateway.fullname" . | trunc (sub 63 (len "-hazelcast") | int) | trimSuffix "-") }}
{{- end }}

{{- define "gateway.hazelcastServiceDns" -}}
{{- printf "%s.%s.svc.cluster.local" (include "gateway.hazelcastServiceName" .) .Release.Namespace }}
{{- end }}

{{/* Whether history rewrites are on: git.enabled and git.rewrite.enabled, the latter refused without Hazelcast. */}}
{{- define "gateway.git.rewrite.enabled" -}}
{{- if and (include "gateway.git.enabled" .) ((.Values.git | default dict).rewrite | default dict).enabled }}
{{- if not (include "gateway.hazelcast.enabled" .) }}
{{- fail "git.rewrite.enabled needs hazelcast.enabled: the per-repo rewrite lock must hold across every gateway replica" }}
{{- end }}true
{{- end }}
{{- end }}

{{/*
The gateway's public origin (GATEWAY_PUBLIC_URL): publicUrl, or https://<ingress.host>.<domain>, the host the main
Ingress publishes. Read through `default` so a release upgraded with --reuse-values from a chart without publicUrl
still derives it.
*/}}
{{- define "gateway.publicUrl" -}}
{{- .Values.publicUrl | default (printf "https://%s.%s" .Values.ingress.host .Values.domain) }}
{{- end }}

{{/*
Whether the gateway serves POST /api/v1/graphql (UI1, CU-1k5g91bqaj5): graphql.enabled when set (true or false), else
whatever auth.enabled is. It takes a browser session only, on the sign-in chain, so graphql.enabled=true without
auth.enabled fails the render (the gateway would refuse to start). Renders "true" or "false".
*/}}
{{- define "gateway.graphql.enabled" -}}
{{- $set := (.Values.graphql | default dict).enabled -}}
{{- $auth := include "gateway.auth.enabled" . -}}
{{- if kindIs "bool" $set -}}
{{- if and $set (not $auth) -}}
{{- fail "graphql.enabled needs auth.enabled: POST /api/v1/graphql takes a browser session only, on the sign-in chain" -}}
{{- end -}}
{{- $set -}}
{{- else -}}
{{- if $auth }}true{{ else }}false{{ end -}}
{{- end -}}
{{- end }}

{{/*
The npm registry's settings (git.npm), each with its default, so values from a release older than the block (an
upgrade with --reuse-values) render exactly as the chart's own defaults.
*/}}
{{- define "gateway.npm.maxPublishSize" -}}
{{- (((.Values.git | default dict).npm | default dict).maxPublishSize | default "16MB") -}}
{{- end }}
{{- define "gateway.npm.ingress.path" -}}
{{- ((((.Values.git | default dict).npm | default dict).ingress | default dict).path | default "/api/v1/registry/npm") -}}
{{- end }}
{{- define "gateway.npm.ingress.proxyBodySize" -}}
{{- ((((.Values.git | default dict).npm | default dict).ingress | default dict).proxyBodySize | default "20m") -}}
{{- end }}
{{- define "gateway.npm.ingress.proxyTimeoutSeconds" -}}
{{- ((((.Values.git | default dict).npm | default dict).ingress | default dict).proxyTimeoutSeconds | default 360) -}}
{{- end }}
