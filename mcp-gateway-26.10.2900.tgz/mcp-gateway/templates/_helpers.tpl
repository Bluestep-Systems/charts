{{/*
Expand the name of the chart.
*/}}
{{- define "mcp-gateway.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
*/}}
{{- define "mcp-gateway.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "mcp-gateway.labels" -}}
helm.sh/chart: {{ include "mcp-gateway.name" . }}-{{ .Chart.Version | replace "+" "_" }}
{{ include "mcp-gateway.selectorLabels" . }}
app.kubernetes.io/version: {{ .Values.image.tag | default .Chart.AppVersion | quote }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "mcp-gateway.selectorLabels" -}}
app.kubernetes.io/name: {{ include "mcp-gateway.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Container image
*/}}
{{- define "mcp-gateway.image" -}}
{{- printf "%s:%s" .Values.image.repository (.Values.image.tag | default .Chart.AppVersion) }}
{{- end }}

{{/*
JVM trust settings (jvmSecurity in values.yaml). The Deployment is this chart's only workload and
takes the helpers below.

Every lookup goes through `.Values.jvmSecurity | default dict`, so a release upgraded with --reuse-values
from a chart that had no jvmSecurity block renders as disabled -- exactly as before -- instead of failing.
*/}}
{{- define "mcp-gateway.jvmSecurity.enabled" -}}
{{- if (.Values.jvmSecurity | default dict).enabled }}true{{ end }}
{{- end }}

{{/*
The two ConfigMap names. The fullname is cut first, leaving room for the longer suffix, so a long
fullname still yields two distinct names of at most 63 characters. Cutting after appending would eat
the suffix and could make both names the same.
*/}}
{{- define "mcp-gateway.jvmSecurityNameBase" -}}
{{- include "mcp-gateway.fullname" . | trunc (sub 63 (len "-jvm-security-local") | int) | trimSuffix "-" }}
{{- end }}

{{- define "mcp-gateway.jvmSecurityName" -}}
{{- printf "%s-jvm-security" (include "mcp-gateway.jvmSecurityNameBase" .) }}
{{- end }}

{{- define "mcp-gateway.jvmSecurityLocalName" -}}
{{- printf "%s-jvm-security-local" (include "mcp-gateway.jvmSecurityNameBase" .) }}
{{- end }}

{{/*
First init container. files/jvm-security-init.sh (kept byte-identical to the campaign's script) guards
java.home, normalises and validates both fingerprint lists, and builds the snapshot the JVM containers
read from the jvm-security-merged emptyDir, merging in the operator's optional -local overlay: blocked.certs (the JDK's list, then ours), cacerts (the
image's own store minus every distrusted anchor) and a validated copy of java.security. The app never
reads the ConfigMap itself, so an in-cluster edit reaches it only through a restart that re-runs this.
No envFrom: it must not pick up the app's settings.
*/}}
{{- define "mcp-gateway.jvmSecurity.initContainer" -}}
{{- $js := .Values.jvmSecurity | default dict }}
- name: jvm-security
  image: {{ include "mcp-gateway.image" . }}
  imagePullPolicy: {{ .Values.image.pullPolicy }}
  command: ["sh", "-ec"]
  args:
    - |
      {{- .Files.Get "files/jvm-security-init.sh" | nindent 6 }}
  env:
    - name: EXPECTED_JAVA_HOME
      value: {{ $js.javaHome | quote }}
  volumeMounts:
    - mountPath: /etc/bluestep/jvm-security-src
      name: jvm-security
      readOnly: true
    - mountPath: /etc/bluestep/jvm-security-local
      name: jvm-security-local
      readOnly: true
    - mountPath: /merged
      name: jvm-security-merged
  securityContext:
    runAsNonRoot: true
    readOnlyRootFilesystem: true
    allowPrivilegeEscalation: false
    capabilities:
      drop: [ALL]
  resources:
    {{- toYaml $js.initResources | nindent 4 }}
{{- end }}

{{/*
Mounts for every container that runs a JVM: the init container's snapshot, never the ConfigMap. The two
subPath mounts lay the merged blocked.certs and the pruned cacerts over the JDK's own. A subPath mount is
never updated in place -- fine, because a change rolls the pod (checksum annotation on a helm upgrade,
Reloader on an edit to the ConfigMap) and the init container rebuilds the snapshot.
*/}}
{{- define "mcp-gateway.jvmSecurity.volumeMounts" -}}
{{- $js := .Values.jvmSecurity | default dict }}
- mountPath: /etc/bluestep/jvm-security
  name: jvm-security-merged
  readOnly: true
- mountPath: {{ printf "%s/lib/security/blocked.certs" $js.javaHome }}
  name: jvm-security-merged
  subPath: blocked.certs
  readOnly: true
- mountPath: {{ printf "%s/lib/security/cacerts" $js.javaHome }}
  name: jvm-security-merged
  subPath: cacerts
  readOnly: true
{{- end }}

{{- define "mcp-gateway.jvmSecurity.volumes" -}}
- name: jvm-security
  configMap:
    name: {{ include "mcp-gateway.jvmSecurityName" . }}
# The operator's overlay (see the values comment above jvmSecurity). Helm never renders it, so an
# emergency edit there survives deploys; optional, so a namespace without one starts as usual.
- name: jvm-security-local
  configMap:
    name: {{ include "mcp-gateway.jvmSecurityLocalName" . }}
    optional: true
- name: jvm-security-merged
  emptyDir:
    sizeLimit: 2Mi
{{- end }}

{{/*
Single "=": the validated copy layers over the JDK's java.security instead of replacing it.
JDK_JAVA_OPTIONS, not JAVA_TOOL_OPTIONS: the image starts the JVM with the java launcher, which reads it,
and JAVA_TOOL_OPTIONS stays free for whatever else sets it.
*/}}
{{- define "mcp-gateway.jvmSecurity.env" -}}
- name: JDK_JAVA_OPTIONS
  value: "-Djava.security.properties=/etc/bluestep/jvm-security/java.security"
{{- end }}
