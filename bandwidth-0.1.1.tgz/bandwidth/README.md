# Bluestep Bandwidth

## Package
```bash
helm package . -d ../../../charts
helm repo index ../../../charts
```
## Publish chart to github
```bash
cd ~/dev/charts
git commit -A -m "Change <New Bandwith Chart update>"
git push
```

## Add to repository to local installation
```bash
helm repo add bluestep-systems https://bluestep-systems.github.io/charts
```

## To update Helm repositories after changes to https://bluestep-systems.github.io/charts
```bash
helm repo update
```