# Kubernetes Logging Configuration

This document explains how to configure logging levels for the OAuth2 Integrator in Kubernetes using ConfigMaps.

## Overview

The OAuth2 Integrator uses a ConfigMap to manage non-sensitive configuration, including logging levels. This allows you to change log levels without rebuilding the container or modifying secrets.

## Configuration Structure

### ConfigMap (Non-Sensitive)
- Logging levels
- Application configuration
- Feature flags

### Secrets (Sensitive)
- OAuth2 credentials (Microsoft, Google)
- Agent authentication tokens

## Changing Logging Levels

### Option 1: Via values.yaml

Edit your `values.yaml` file:

```yaml
config:
  enabled: true
  logging:
    # Spring Security log level (DEBUG, INFO, WARN, ERROR)
    springSecurityLevel: "DEBUG"  # Change this for verbose OAuth debugging
    # Root logger level
    rootLevel: "INFO"
    # Application logger level
    appLevel: "DEBUG"  # Change this to see your custom logs
```

Then upgrade the Helm release:

```bash
helm upgrade oauth2-integrator ./helm -f values.yaml
```

### Option 2: Via Helm Command Line

Override values directly during upgrade:

```bash
helm upgrade oauth2-integrator ./helm \
  --set config.logging.springSecurityLevel=DEBUG \
  --set config.logging.appLevel=DEBUG
```

### Option 3: Edit ConfigMap Directly (Quick Changes)

For temporary debugging without a full deployment:

```bash
# Edit the ConfigMap
kubectl edit configmap oauth2-integrator

# Change SPRING_SECURITY_LOG_LEVEL from INFO to DEBUG
# Save and exit

# Restart pods to pick up new config
kubectl rollout restart deployment oauth2-integrator
```

## Available Log Levels

| Level | Description | Use Case |
|-------|-------------|----------|
| `ERROR` | Only errors | Production (minimal logging) |
| `WARN` | Warnings and errors | Production (normal) |
| `INFO` | Informational messages | Production (recommended) |
| `DEBUG` | Detailed debugging info | Development/Troubleshooting |
| `TRACE` | Very verbose | Deep debugging (not recommended) |

## Environment Variables in ConfigMap

The ConfigMap creates the following environment variables:

| Variable | Description | Default |
|----------|-------------|---------|
| `SPRING_SECURITY_LOG_LEVEL` | Spring Security OAuth2 logging | `INFO` |
| `LOGGING_LEVEL_ROOT` | Root logger level | `INFO` |
| `LOGGING_LEVEL_DEV_BLUESTEP_OAUTH2_INTEGRATOR` | Application logger level | `INFO` |

## Example Scenarios

### Debugging OAuth Flow Issues

```yaml
config:
  logging:
    springSecurityLevel: "DEBUG"  # See OAuth2 flow details
    appLevel: "DEBUG"              # See custom authentication logic
```

### Production (Minimal Logs)

```yaml
config:
  logging:
    springSecurityLevel: "INFO"
    appLevel: "INFO"
```

### Investigating Performance Issues

```yaml
config:
  logging:
    rootLevel: "WARN"              # Reduce overall logging
    appLevel: "INFO"               # Keep application logs
    springSecurityLevel: "WARN"   # Reduce security logs
```

## Adding Custom Environment Variables

You can add additional environment variables to the ConfigMap:

```yaml
config:
  extraEnv:
    CUSTOM_FEATURE_FLAG: "true"
    MAX_RETRY_ATTEMPTS: "3"
```

These will be automatically added to the ConfigMap and available to your application.

## Viewing Current Configuration

```bash
# View the ConfigMap
kubectl get configmap oauth2-integrator -o yaml

# View environment variables in running pod
kubectl exec oauth2-integrator-xxx -- env | grep LOG
```

## Troubleshooting

### Changes Not Taking Effect

1. Verify ConfigMap was updated:
   ```bash
   kubectl describe configmap oauth2-integrator
   ```

2. Restart the deployment:
   ```bash
   kubectl rollout restart deployment oauth2-integrator
   ```

3. Check pod environment variables:
   ```bash
   kubectl exec <pod-name> -- env | grep SPRING_SECURITY_LOG_LEVEL
   ```

### Logs Still Too Verbose

If you're seeing too many logs even at INFO level, you can selectively reduce logging for specific packages:

```yaml
config:
  extraEnv:
    LOGGING_LEVEL_ORG_SPRINGFRAMEWORK_WEB: "WARN"
    LOGGING_LEVEL_ORG_SPRINGFRAMEWORK_SECURITY: "INFO"
```

## Best Practices

1. **Default to INFO in production** - Provides good visibility without excessive noise
2. **Use DEBUG temporarily** - Enable DEBUG logging when troubleshooting, then revert
3. **Monitor log volume** - High log levels can impact performance and storage
4. **Use structured logging** - All logs use SLF4J with parameterized messages
5. **Leverage log aggregation** - ConfigMap logs work perfectly with ELK, Splunk, Datadog, etc.

## Related Files

- `helm/templates/configmap.yaml` - ConfigMap template
- `helm/templates/deployment.yaml` - Deployment with ConfigMap reference
- `helm/values.yaml` - Default configuration values
- `src/main/resources/application.yml` - Application logging configuration
