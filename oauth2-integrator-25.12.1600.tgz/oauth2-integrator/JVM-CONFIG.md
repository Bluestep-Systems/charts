# JVM Configuration Guide

This guide explains how to add any Java JVM arguments to the OAuth2 Integrator without modifying the Dockerfile.

## How It Works

The Helm chart uses `JAVA_TOOL_OPTIONS` environment variable, which the JVM automatically reads and applies at startup. This means you can add **any** JVM argument via ConfigMap without rebuilding the Docker image.

## Quick Start

### Via values.yaml

```yaml
config:
  jvm:
    extraArgs: "-Xms512m -Xmx2g -XX:+UseG1GC"
```

### Via Helm Command

```bash
helm upgrade oauth2-integrator ./helm \
  --namespace b6p-system \
  --set config.jvm.extraArgs="-Xms512m -Xmx2g"
```

### Via ConfigMap Edit

```bash
kubectl edit configmap oauth2-integrator -n b6p-system

# Edit the JAVA_TOOL_OPTIONS line:
#   JAVA_TOOL_OPTIONS: "-Xms512m -Xmx2g -XX:+UseG1GC"

kubectl rollout restart deployment/oauth2-integrator -n b6p-system
```

## Common JVM Arguments

### Memory Settings

```yaml
config:
  jvm:
    # Set initial and maximum heap size
    extraArgs: "-Xms1g -Xmx4g"
```

**When to use:**
- Application needs more memory than default
- Want to reduce GC frequency
- Running memory-intensive operations

### Garbage Collection

```yaml
config:
  jvm:
    # Use G1 GC with tuning
    extraArgs: "-XX:+UseG1GC -XX:MaxGCPauseMillis=200 -XX:ParallelGCThreads=4"
```

**Popular GC options:**
- `-XX:+UseG1GC` - G1 garbage collector (default in Java 9+)
- `-XX:+UseZGC` - Low-latency ZGC (Java 15+)
- `-XX:+UseShenandoahGC` - Shenandoah GC
- `-XX:MaxGCPauseMillis=200` - Target max GC pause

### GC Logging

```yaml
config:
  jvm:
    extraArgs: "-Xlog:gc*:file=/tmp/gc.log:time,uptime:filecount=5,filesize=10m"
```

### System Properties

```yaml
config:
  jvm:
    # Spring profiles and custom properties
    extraArgs: "-Dspring.profiles.active=dev -Dserver.tomcat.max-threads=200"
```

### JMX Monitoring

```yaml
config:
  jvm:
    extraArgs: >-
      -Dcom.sun.management.jmxremote
      -Dcom.sun.management.jmxremote.port=9010
      -Dcom.sun.management.jmxremote.authenticate=false
      -Dcom.sun.management.jmxremote.ssl=false
```

Don't forget to expose the JMX port in the service!

### Java Flight Recorder (JFR)

```yaml
config:
  jvm:
    # Start recording on startup
    extraArgs: "-XX:StartFlightRecording=duration=60s,filename=/tmp/recording.jfr"
```

### String Deduplication

```yaml
config:
  jvm:
    # Reduce memory usage from duplicate strings
    extraArgs: "-XX:+UseStringDeduplication"
```

### Assertion Mode

```yaml
config:
  jvm:
    # Enable assertions (useful for development)
    extraArgs: "-ea"
```

## Combined with Debugging

The ConfigMap template automatically combines debug and JVM args:

```yaml
config:
  debug:
    enabled: true
    port: 50005
  jvm:
    extraArgs: "-Xms1g -Xmx4g -XX:+UseG1GC"
```

Results in:
```
JAVA_TOOL_OPTIONS: "-agentlib:jdwp=transport=dt_socket,address=*:50005,server=y,suspend=n -Xms1g -Xmx4g -XX:+UseG1GC"
```

## Real-World Examples

### Development Environment

```yaml
config:
  logging:
    springSecurityLevel: "DEBUG"
    appLevel: "DEBUG"
  debug:
    enabled: true
    port: 50005
  jvm:
    extraArgs: "-Xms256m -Xmx1g -ea"
```

### Production Environment

```yaml
config:
  logging:
    springSecurityLevel: "INFO"
    appLevel: "INFO"
  debug:
    enabled: false
  jvm:
    extraArgs: >-
      -Xms2g
      -Xmx4g
      -XX:+UseG1GC
      -XX:MaxGCPauseMillis=200
      -XX:+HeapDumpOnOutOfMemoryError
      -XX:HeapDumpPath=/tmp/heapdump.hprof
```

### Performance Tuning

```yaml
config:
  jvm:
    extraArgs: >-
      -Xms2g
      -Xmx4g
      -XX:+UseG1GC
      -XX:MaxGCPauseMillis=100
      -XX:+UseStringDeduplication
      -XX:+ParallelRefProcEnabled
      -Xlog:gc*:file=/tmp/gc.log:time,uptime:filecount=5,filesize=10m
```

### Memory Constrained

```yaml
config:
  jvm:
    extraArgs: >-
      -Xms128m
      -Xmx512m
      -XX:+UseSerialGC
      -XX:MaxMetaspaceSize=256m
```

## Dockerfile vs JAVA_TOOL_OPTIONS

### Current Dockerfile
```dockerfile
ENTRYPOINT ["java", \
    "-XX:MaxRAMPercentage=75.0", \
    "-XX:+ExitOnOutOfMemoryError", \
    "-Djava.security.egd=file:/dev/./urandom", \
    "-jar", "app.jar"]
```

### With JAVA_TOOL_OPTIONS
```yaml
config:
  jvm:
    extraArgs: "-Xms1g -Xmx2g"
```

### Final JVM Command (Combined)
```bash
java \
  -Xms1g -Xmx2g \                              # From JAVA_TOOL_OPTIONS
  -XX:MaxRAMPercentage=75.0 \                  # From Dockerfile
  -XX:+ExitOnOutOfMemoryError \                # From Dockerfile
  -Djava.security.egd=file:/dev/./urandom \    # From Dockerfile
  -jar app.jar
```

**JAVA_TOOL_OPTIONS is prepended to Dockerfile args!**

## Viewing Effective JVM Arguments

```bash
# View JAVA_TOOL_OPTIONS in ConfigMap
kubectl get configmap oauth2-integrator -n b6p-system -o yaml | grep JAVA_TOOL_OPTIONS

# View environment variable in running pod
kubectl exec deployment/oauth2-integrator -n b6p-system -- env | grep JAVA_TOOL_OPTIONS

# View all JVM flags in running JVM
kubectl exec deployment/oauth2-integrator -n b6p-system -- jcmd 1 VM.flags
```

## Limitations

### What Works ✅
- `-Xms`, `-Xmx` (heap size)
- `-XX:+UseG1GC` (GC flags)
- `-Dkey=value` (system properties)
- `-agentlib:`, `-javaagent:` (agents)
- `-verbose:gc` (verbose flags)
- `-ea`, `-esa` (assertions)

### What Doesn't Work ❌
- Classpath changes (`-cp`, `-classpath`)
  - These are in the Dockerfile already
- Module system (`--module-path`)
  - Requires Dockerfile changes
- Arguments that come after `-jar`
  - Use Spring Boot properties instead

### If You Need Dockerfile Changes

Some things require rebuilding the image:
- Changing the JAR file
- Adding external dependencies
- Modifying classpath
- Adding native libraries

## Monitoring Changes

After updating JVM args:

```bash
# 1. Update ConfigMap
helm upgrade oauth2-integrator ./helm --set config.jvm.extraArgs="-Xms1g" -n b6p-system

# 2. Restart pods
kubectl rollout restart deployment/oauth2-integrator -n b6p-system

# 3. Watch logs for JVM startup
kubectl logs -f deployment/oauth2-integrator -n b6p-system | grep -i "jvm\|heap\|gc"

# 4. Verify memory settings
kubectl exec deployment/oauth2-integrator -n b6p-system -- java -XX:+PrintFlagsFinal -version | grep -i heap
```

## Troubleshooting

### JVM Won't Start

**Check for typos:**
```bash
# View exact value
kubectl get configmap oauth2-integrator -n b6p-system -o jsonpath='{.data.JAVA_TOOL_OPTIONS}'
```

**Check pod logs:**
```bash
kubectl logs deployment/oauth2-integrator -n b6p-system
```

**Common errors:**
- Unrecognized option: `-XX:+UnknownFlag`
- Invalid heap size: `-Xmx10z` (use `-Xmx10g`)
- Conflicting GC: Can't use multiple GC algorithms

### Memory Issues

**Check memory limits:**
```bash
kubectl describe pod <pod-name> -n b6p-system | grep -A5 Limits
```

**OOMKilled:**
- Increase `-Xmx` (but stay under pod memory limit!)
- Or increase pod memory limit in values.yaml

### Performance Degraded

**Too much memory:**
- Large heaps = longer GC pauses
- Consider `-XX:MaxGCPauseMillis=200`

**Too little memory:**
- Frequent GC
- Increase `-Xmx`

## Best Practices

1. **Start conservative:**
   ```yaml
   extraArgs: "-Xms512m -Xmx1g"
   ```

2. **Monitor in dev first:**
   - Test changes in dev environment
   - Monitor GC logs and memory usage
   - Then apply to production

3. **Use container-aware flags:**
   ```yaml
   # Let JVM auto-detect container memory (already in Dockerfile)
   # -XX:MaxRAMPercentage=75.0
   ```

4. **Document why:**
   ```yaml
   jvm:
     # Increased heap for large OAuth token processing
     extraArgs: "-Xms2g -Xmx4g"
   ```

5. **Version control:**
   - Keep JVM args in values.yaml
   - Track changes in git
   - Document performance impact

## References

- [JVM Options Reference](https://docs.oracle.com/en/java/javase/21/docs/specs/man/java.html)
- [GC Tuning Guide](https://docs.oracle.com/en/java/javase/21/gctuning/)
- [JFR Documentation](https://docs.oracle.com/javacomponents/jmc-5-4/jfr-runtime-guide/about.htm)

## Related Documentation

- [DEBUG-CONFIG.md](DEBUG-CONFIG.md) - Remote debugging setup
- [LOGGING-CONFIG.md](LOGGING-CONFIG.md) - Logging configuration
- [DEV-DEPLOY.md](../DEV-DEPLOY.md) - Development deployment
