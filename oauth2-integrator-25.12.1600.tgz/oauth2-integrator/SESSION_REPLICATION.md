# Session Replication Configuration

This document explains how to configure session replication for the OAuth2 Integrator when running multiple pods in Kubernetes.

## Overview

The OAuth2 Integrator uses **Tomcat clustering with DNS-based membership** to replicate sessions across pods. This ensures that OAuth2 authentication flows work correctly even when:

- Multiple pods are running behind a load balancer
- Pod restarts occur during active sessions
- Rolling deployments are in progress

## Architecture

### Without Session Replication (Default)
```
User → Load Balancer → Pod A (has session)
User → Load Balancer → Pod B (no session) ❌ User must login again
```

### With Session Replication
```
User → Load Balancer → Pod A (creates session)
                        ↓ (session replicated)
User → Load Balancer → Pod B (has session) ✅ User stays logged in
```

## How It Works

1. **DNS-based Discovery**: Uses a headless service to discover pod IPs via DNS lookups
2. **Tomcat Tribes**: Built-in Tomcat clustering for session replication
3. **In-Memory Sync**: Sessions are replicated in-memory across all pods
4. **Automatic Failover**: If a pod dies, sessions are available on other pods
5. **Simple Setup**: No RBAC permissions needed - just DNS lookups

## Configuration

### 1. Enable Session Replication in values.yaml

```yaml
# Single pod - no replication needed
replicaCount: 1
sessionReplication:
  enabled: false

# Multiple pods - enable replication
replicaCount: 2
sessionReplication:
  enabled: true
  port: 4000  # Port for cluster communication
```

### 2. Optional: Use with Ingress Sticky Sessions

For best performance, combine session replication with Nginx sticky sessions:

```yaml
ingress:
  enabled: true
  className: nginx
  annotations:
    nginx.ingress.kubernetes.io/affinity: "cookie"
    nginx.ingress.kubernetes.io/session-cookie-name: "oauth2-affinity"
    nginx.ingress.kubernetes.io/session-cookie-max-age: "1800"
```

**Benefits of this approach:**
- ✅ Nginx routes users to same pod (reduces cross-pod traffic)
- ✅ If that pod dies, session still available on other pods
- ✅ Best of both worlds: performance + reliability

### 3. Deploy

```bash
helm upgrade --install oauth2-integrator ./helm \
  --set replicaCount=2 \
  --set sessionReplication.enabled=true \
  --set secrets.oauth2.agentToken="your-secret" \
  --set secrets.microsoft.clientId="your-client-id" \
  --set secrets.microsoft.clientSecret="your-secret"
```

## What Gets Created

When `sessionReplication.enabled=true`, Helm creates:

1. **Headless Service** (`oauth2-integrator-headless`)
   - ClusterIP: None (headless service for DNS lookups)
   - Exposes cluster port (default: 4000)
   - Used by DNSMembershipProvider to discover pod IPs

2. **Cluster Port** (default: 4000)
   - Used for Tomcat Tribes communication
   - TCP traffic between pods for session sync

3. **Environment Variables**
   - `SESSION_REPLICATION_ENABLED=true`
   - `SESSION_REPLICATION_PORT=4000`
   - `DNS_MEMBERSHIP_SERVICE_NAME=oauth2-integrator-headless.<namespace>.svc.cluster.local`

## Monitoring

Check if clustering is working:

```bash
# View logs for clustering activity
kubectl logs -l app.kubernetes.io/name=oauth2-integrator --tail=50 | grep -i "cluster\|tribes"

# Expected output:
# Configuring Tomcat session replication with DNS-based pod discovery using service: oauth2-integrator-headless...
# Tomcat clustering configured successfully with DNS-based discovery
```

## Troubleshooting

### Pods can't discover each other

**Symptoms:** Logs show "No members found", "Membership empty", or DNS resolution errors

**Solution:**
```bash
# 1. Check if headless service exists
kubectl get svc -l app.kubernetes.io/component=session-replication

# 2. Verify DNS resolution from inside a pod
kubectl exec -it <pod-name> -- nslookup oauth2-integrator-headless

# 3. Check if pods are running
kubectl get pods -l app.kubernetes.io/name=oauth2-integrator

# 4. View pod logs for DNS or clustering errors
kubectl logs -l app.kubernetes.io/name=oauth2-integrator --tail=50 | grep -E "dns|membership|cluster"

# 5. Verify environment variables are set
kubectl exec -it <pod-name> -- env | grep DNS_MEMBERSHIP
```

### Port conflicts

**Symptoms:** Pods crash with "Address already in use" on port 4000

**Solution:** Change the cluster port in values.yaml:
```yaml
sessionReplication:
  port: 4001  # Use different port
```

### High network traffic

**Symptoms:** Network usage increases significantly

**Explanation:** Session data is replicated to all pods. This is normal.

**Optimization:**
1. Use sticky sessions to reduce cross-pod lookups
2. Reduce `server.servlet.session.timeout` if you don't need 30-minute sessions
3. Consider external session store (Redis) if running 5+ pods

## Performance Considerations

| Configuration | Pods | Best For | Trade-offs |
|---------------|------|----------|------------|
| Sticky sessions only | 2-3 | Low traffic | Sessions lost on pod restart |
| Session replication | 2-5 | Production | Higher memory usage |
| Session replication + sticky | 2-5 | **Recommended** | Best reliability + performance |
| External store (Redis) | 5+ | High scale | Additional infrastructure |

## When NOT to Use

- **Single pod deployment**: No need for replication
- **Stateless authentication**: If using JWT tokens instead of sessions
- **Very high scale (10+ pods)**: Consider Redis instead

## Security Notes

### RBAC Permissions
- **Minimal permissions**: Only `get`, `list`, `watch` on `pods` and `endpoints`
- **Namespace-scoped**: Uses `Role` (not `ClusterRole`) - limited to same namespace
- **Read-only**: Cannot create, update, or delete any resources
- **Purpose**: Required for pod discovery via Kubernetes API
- **Automatic**: Created/deleted with Helm chart when `sessionReplication.enabled=true`

### Network Security
- Cluster communication is **not encrypted** by default (Tomcat Tribes limitation)
- Only deploy in trusted Kubernetes networks
- Use NetworkPolicies to restrict cluster port (4000) access to same namespace
- Consider using a service mesh (Istio, Linkerd) for mTLS between pods

## See Also

- [Tomcat Clustering Documentation](https://tomcat.apache.org/tomcat-10.1-doc/cluster-howto.html)
- [Kubernetes Headless Services](https://kubernetes.io/docs/concepts/services-networking/service/#headless-services)
