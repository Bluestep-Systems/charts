# Java Remote Debugging Configuration

This guide explains how to enable and use Java remote debugging with the OAuth2 Integrator in Kubernetes.

## Quick Start

### Enable Debugging via values.yaml

```yaml
config:
  debug:
    enabled: true    # Enable Java remote debugging
    port: 50005      # Debug port (default: 50005)
```

### Enable Debugging via Helm Command

```bash
# Enable debugging
helm upgrade oauth2-integrator ./helm \
  --namespace b6p-system \
  --set config.debug.enabled=true \
  --set config.debug.port=50005

# Or during install
helm install oauth2-integrator ./helm \
  --namespace b6p-system \
  --set config.debug.enabled=true
```

### Enable Debugging via ConfigMap

```bash
# Edit the ConfigMap directly
kubectl edit configmap oauth2-integrator -n b6p-system

# Add this line under 'data:':
#   JAVA_TOOL_OPTIONS: "-agentlib:jdwp=transport=dt_socket,address=*:50005,server=y,suspend=n"

# Restart pods to pick up the change
kubectl rollout restart deployment/oauth2-integrator -n b6p-system
```

## What Gets Configured

When `config.debug.enabled: true`, the Helm chart:

1. **Sets `JAVA_TOOL_OPTIONS` in ConfigMap:**
   ```
   JAVA_TOOL_OPTIONS: "-agentlib:jdwp=transport=dt_socket,address=*:50005,server=y,suspend=n"
   ```

2. **Exposes debug port in Deployment:**
   ```yaml
   ports:
     - name: debug
       containerPort: 50005
       protocol: TCP
   ```

3. **Exposes debug port in Service:**
   ```yaml
   ports:
     - name: debug
       port: 50005
       targetPort: debug
       protocol: TCP
   ```

## Connect from IDE

### IntelliJ IDEA

1. **Run → Edit Configurations**
2. **Add → Remote JVM Debug**
3. **Configuration:**
   - Name: `oauth2-integrator (Kubernetes)`
   - Debugger mode: `Attach to remote JVM`
   - Host: `localhost` (after port-forward)
   - Port: `50005`
   - Command line arguments: `-agentlib:jdwp=transport=dt_socket,address=*:50005,server=y,suspend=n`

4. **Port Forward:**
   ```bash
   kubectl port-forward service/oauth2-integrator 50005:50005 -n b6p-system
   ```

5. **Click Debug** in IntelliJ

### VS Code

1. **Create `.vscode/launch.json`:**
   ```json
   {
     "version": "0.2.0",
     "configurations": [
       {
         "type": "java",
         "name": "Debug oauth2-integrator (Kubernetes)",
         "request": "attach",
         "hostName": "localhost",
         "port": 50005
       }
     ]
   }
   ```

2. **Port Forward:**
   ```bash
   kubectl port-forward service/oauth2-integrator 50005:50005 -n b6p-system
   ```

3. **Run → Start Debugging**

### Eclipse

1. **Run → Debug Configurations**
2. **Remote Java Application → New**
3. **Configuration:**
   - Project: `oauth2-integrator`
   - Connection Type: `Standard (Socket Attach)`
   - Host: `localhost`
   - Port: `50005`

4. **Port Forward:**
   ```bash
   kubectl port-forward service/oauth2-integrator 50005:50005 -n b6p-system
   ```

5. **Click Debug**

## Port Forwarding

Before connecting your debugger, you need to forward the debug port:

```bash
# Forward debug port
kubectl port-forward service/oauth2-integrator 50005:50005 -n b6p-system --context local

# Keep this running in a separate terminal
```

## Development Workflow

### 1. Build and Deploy with Debugging Enabled

```bash
# Deploy with debugging
./dev-helm-deploy.sh
```

Then manually enable debug via Helm:
```bash
helm upgrade oauth2-integrator ./helm \
  --namespace b6p-system \
  --set config.debug.enabled=true \
  --reuse-values
```

### 2. Port Forward

```bash
kubectl port-forward service/oauth2-integrator 50005:50005 -n b6p-system --context local
```

### 3. Set Breakpoints

Set breakpoints in your IDE in files like:
- `CustomAuthenticationSuccessHandler.java`
- `InitiationController.java`
- `SecurityConfig.java`

### 4. Attach Debugger

Connect from your IDE (see above)

### 5. Trigger OAuth Flow

```bash
# Initiate Microsoft login
curl http://localhost:8080/oauth2/authorization/microsoft

# Initiate Google login
curl http://localhost:8080/oauth2/authorization/google
```

Your breakpoints should hit!

## Debug Parameters Explained

```
-agentlib:jdwp=transport=dt_socket,address=*:50005,server=y,suspend=n
```

| Parameter | Value | Description |
|-----------|-------|-------------|
| `transport` | `dt_socket` | Use socket transport |
| `address` | `*:50005` | Listen on all interfaces, port 50005 |
| `server` | `y` | Act as debug server (IDE connects to it) |
| `suspend` | `n` | Don't wait for debugger to attach before starting |

### When to Use `suspend=y`

Change to `suspend=y` if you want the JVM to wait for debugger before starting:

```yaml
config:
  extraEnv:
    JAVA_TOOL_OPTIONS: "-agentlib:jdwp=transport=dt_socket,address=*:50005,server=y,suspend=y"
```

This is useful for debugging startup issues.

## Security Considerations

⚠️ **Never enable debugging in production!**

Debug ports allow full access to the JVM, including:
- Reading all memory
- Executing arbitrary code
- Modifying variables
- Stepping through code

**Only enable in:**
- ✅ Local development (dev environment)
- ✅ Isolated test environments
- ❌ **NEVER** in production

## Troubleshooting

### Cannot Connect to Debugger

**Check port-forward is running:**
```bash
# Should show output like: Forwarding from 127.0.0.1:50005 -> 50005
kubectl port-forward service/oauth2-integrator 50005:50005 -n b6p-system
```

**Check debug port is exposed:**
```bash
kubectl get svc oauth2-integrator -n b6p-system -o yaml | grep -A5 "port: 50005"
```

**Check JAVA_TOOL_OPTIONS is set:**
```bash
kubectl exec deployment/oauth2-integrator -n b6p-system -- env | grep JAVA_TOOL_OPTIONS
```

### Debugger Connects But Breakpoints Don't Hit

**Verify source matches deployed version:**
- Ensure you've deployed your latest code
- Check git commit matches deployed image

**Check breakpoint location:**
- Set breakpoint in code that will definitely execute
- Try the home endpoint: `curl http://localhost:8080/`

### Port Already in Use

If port 50005 is already in use, change the debug port:

```bash
helm upgrade oauth2-integrator ./helm \
  --namespace b6p-system \
  --set config.debug.port=50006 \
  --reuse-values

kubectl port-forward service/oauth2-integrator 50006:50006 -n b6p-system
```

## Disable Debugging

### Via Helm

```bash
helm upgrade oauth2-integrator ./helm \
  --namespace b6p-system \
  --set config.debug.enabled=false \
  --reuse-values
```

### Via ConfigMap

```bash
kubectl edit configmap oauth2-integrator -n b6p-system

# Remove the JAVA_TOOL_OPTIONS line
# Save and exit

kubectl rollout restart deployment/oauth2-integrator -n b6p-system
```

## Performance Impact

Enabling debugging has minimal performance impact when no debugger is attached:
- ~1-2% CPU overhead
- ~10-20 MB additional memory
- No impact when `suspend=n` and no debugger connected

When debugger is attached and stepping through code:
- Application pauses at breakpoints
- Slower execution during step-through
- Normal performance when running

## Example: Debug Microsoft OAuth Flow

1. **Enable debugging and deploy:**
   ```bash
   ./dev-helm-deploy.sh
   helm upgrade oauth2-integrator ./helm --set config.debug.enabled=true --reuse-values -n b6p-system
   ```

2. **Port forward:**
   ```bash
   kubectl port-forward service/oauth2-integrator 50005:50005 -n b6p-system
   ```

3. **Set breakpoint:**
   - Open `CustomAuthenticationSuccessHandler.java`
   - Set breakpoint at line: `if (authentication.getPrincipal() instanceof final OidcUser oidcUser)`

4. **Attach debugger from IntelliJ**

5. **Trigger OAuth:**
   ```bash
   # Port forward the service too
   kubectl port-forward service/oauth2-integrator 8080:8080 -n b6p-system

   # Open in browser
   open http://localhost:8080/oauth2/authorization/microsoft
   ```

6. **Breakpoint should hit!** Step through the OAuth flow and inspect variables.

## Related Documentation

- [LOGGING-CONFIG.md](LOGGING-CONFIG.md) - Configure logging levels
- [DEV-DEPLOY.md](../DEV-DEPLOY.md) - Development deployment scripts
