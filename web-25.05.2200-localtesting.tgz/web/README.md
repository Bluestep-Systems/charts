# Bleustep Web Application

## Package
```bash
../package.sh
cd  ../../charts
git add -A
git commit -m "some message"
git push
```
## Add to repository to local installation
```bash
helm repo add bluestep-systems https://bluestep-systems.github.io/charts
```

## To update Helm repositories after changes to https://bluestep-systems.github.io/charts
```bash
helm repo update
```