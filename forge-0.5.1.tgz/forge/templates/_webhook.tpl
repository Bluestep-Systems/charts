{{/*
The webhook allow-list as Forgejo must see it. Never empty: Forgejo treats an empty ALLOWED_HOST_LIST as
"external" (any public host). With no targets, an unresolvable name allows nothing.
*/}}
{{- define "forge.webhookAllowedHosts" -}}
{{- if .Values.webhook.allowedHosts -}}
{{- .Values.webhook.allowedHosts -}}
{{- else if .Values.replicator.enabled -}}
{{- .Values.replicator.serviceHost -}}
{{- else -}}
localhost.invalid
{{- end -}}
{{- end -}}
