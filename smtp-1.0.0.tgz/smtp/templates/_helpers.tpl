{{/* vim: set filetype=mustache: */}}
{{/*
Expand the name of the chart.
*/}}
{{- define "smtp.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the SMTP naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "smtp.fullname" -}}
{{- if .Values.fullnameOverride -}}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- $name := default .Chart.Name .Values.nameOverride -}}
{{- if contains $name .Release.Name -}}
{{- .Release.Name | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" -}}
{{- end -}}
{{- end -}}
{{- end -}}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "smtp.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
Common labels
*/}}
{{- define "smtp.labels" -}}
helm.sh/chart: {{ include "smtp.chart" . }}
app.kubernetes.io/part-of: bluestep
{{ include "smtp.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end -}}

{{/*
Selector labels
*/}}
{{- define "smtp.selectorLabels" -}}
app.kubernetes.io/name: {{ include "smtp.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end -}}

{{/*
Create the name of the service account to use
*/}}
{{- define "smtp.serviceAccountName" -}}
{{- if .Values.serviceAccount.create -}}
    {{ default (include "smtp.fullname" .) .Values.serviceAccount.name }}
{{- else -}}
    {{ default "default" .Values.serviceAccount.name }}
{{- end -}}
{{- end -}}

{{- define "smtp.allowedSenderDomains" -}}
  {{- if .Values.allowedSenderDomains -}}
      {{- .Values.allowedSenderDomains -}}
  {{- else -}}
    {{- range $k, $v := .Values.dkim -}}
      {{- printf "%s " $v.domainName -}} 
    {{- end -}}
  {{- end -}}
{{- end -}}

{{- define "smtp.dkimSelector" -}}
  {{- $local := dict "first" true -}}
  {{- range $k, $v := .Values.dkim -}}
    {{- if not $local.first -}},{{- end -}}
    {{- $v.domainName}}={{$v.selector -}}
    {{- $_ := set $local "first" false -}}
  {{- end -}}
{{- end -}}
