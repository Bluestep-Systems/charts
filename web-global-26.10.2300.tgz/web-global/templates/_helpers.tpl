{{/*
Expand the name of the chart.
*/}}
{{- define "web-global.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
*/}}
{{- define "web-global.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "web-global.labels" -}}
helm.sh/chart: {{ include "web-global.name" . }}-{{ .Chart.Version | replace "+" "_" }}
{{ include "web-global.selectorLabels" . }}
app.kubernetes.io/version: {{ .Values.image.tag | default .Chart.AppVersion | quote }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "web-global.selectorLabels" -}}
app.kubernetes.io/name: {{ include "web-global.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Container image
*/}}
{{- define "web-global.image" -}}
{{- printf "%s:%s" .Values.image.repository (.Values.image.tag | default .Chart.AppVersion) }}
{{- end }}

{{/*
Headless Service name used by Hazelcast Kubernetes DNS discovery.
*/}}
{{- define "web-global.hazelcastServiceName" -}}
{{- printf "%s-hazelcast" (include "web-global.fullname" .) | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Fully qualified DNS name (cluster.local) for the headless Hazelcast service.
*/}}
{{- define "web-global.hazelcastServiceDns" -}}
{{- printf "%s.%s.svc.cluster.local" (include "web-global.hazelcastServiceName" .) .Release.Namespace }}
{{- end }}

{{/*
Name of the marker key External Secrets writes into the target Secret once it has reconciled
this exact ExternalSecret spec. The name carries a hash of the spec Helm renders, so the
secrets volume, whose items name the key, cannot mount for a pod while the Secret still
holds what ESO synced from an older spec -- a remapped key that already exists would otherwise pass.
A value changed only in BWS leaves the spec, and so the name, unchanged.
*/}}
{{- define "web-global.esoSyncedKey" -}}
B6P_ESO_SYNCED_{{ dict "store" .Values.eso.secretStoreRef "data" .Values.eso.data | toJson | sha256sum | trunc 12 }}
{{- end -}}
