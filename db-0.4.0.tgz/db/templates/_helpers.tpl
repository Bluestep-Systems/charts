{{/* vim: set filetype=mustache: */}}
{{/*
Expand the name of the chart.
*/}}
{{- define "db.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "db.fullname" -}}
{{- if .Values.fullnameOverride -}}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- $name := default .Chart.Name .Values.nameOverride -}}
{{- if contains $name .Release.Name -}}
{{- .Release.Name | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" -}}
{{- end -}}
{{- end -}}
{{- end -}}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "db.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
Common labels
*/}}
{{- define "db.labels" -}}
helm.sh/chart: {{ include "db.chart" . }}
app.kubernetes.io/part-of: bluestep
{{ include "db.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end -}}

{{/*
Selector labels
*/}}
{{- define "db.selectorLabels" -}}
app.kubernetes.io/name: {{ include "db.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end -}}

{{/*
Create the name of the service account to use
*/}}
{{- define "db.serviceAccountName" -}}
{{- if .Values.serviceAccount.create -}}
    {{ default (include "db.fullname" .) .Values.serviceAccount.name }}
{{- else -}}
    {{ default "default" .Values.serviceAccount.name }}
{{- end -}}
{{- end -}}

{{/*
The container image. A digest pins the exact build; a tag must name a version.
`latest` (or no tag) is refused: the mutable b6p-db:14.5 tag is how UT's global DB
came to run PG 14.5 while AZ's ran 14.9 under the same spec.
*/}}
{{- define "db.image" -}}
{{- $i := .Values.image -}}
{{- if $i.digest -}}
{{ $i.repository }}@{{ $i.digest }}
{{- else -}}
{{- $tag := toString ($i.tag | default "") -}}
{{- if or (eq $tag "") (eq $tag "latest") -}}
{{- fail "db chart: image.tag must name a version (not empty or \"latest\"), or set image.digest" -}}
{{- end -}}
{{ $i.repository }}:{{ $tag }}
{{- end -}}
{{- end -}}

{{/*
B6P_ALLOW_INITDB for the entrypoint. allowInitdb: auto (the default) allows initdb
only on a first `helm install`; every upgrade renders false, so a pod that comes up
on an empty volume refuses to start instead of serving a new, empty database.
*/}}
{{- define "db.allowInitdb" -}}
{{- $v := "auto" -}}
{{- if hasKey .Values "allowInitdb" -}}{{- $v = toString .Values.allowInitdb -}}{{- end -}}
{{- if eq $v "auto" -}}{{- $v = ternary "true" "false" .Release.IsInstall -}}{{- end -}}
{{- if not (has $v (list "true" "false")) -}}
{{- fail (printf "db chart: allowInitdb must be auto, true or false, got %v" .Values.allowInitdb) -}}
{{- end -}}
{{- $v -}}
{{- end -}}
