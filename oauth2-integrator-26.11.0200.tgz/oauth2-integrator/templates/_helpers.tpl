{{/*
Expand the name of the chart.
*/}}
{{- define "oauth2-redirector.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "oauth2-redirector.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "oauth2-redirector.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "oauth2-redirector.labels" -}}
helm.sh/chart: {{ include "oauth2-redirector.chart" . }}
{{ include "oauth2-redirector.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "oauth2-redirector.selectorLabels" -}}
app.kubernetes.io/name: {{ include "oauth2-redirector.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Create the name of the service account to use
*/}}
{{- define "oauth2-redirector.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- default (include "oauth2-redirector.fullname" .) .Values.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.serviceAccount.name }}
{{- end }}
{{- end }}

{{/*
Name of the marker key External Secrets writes into the target Secret once it has reconciled
this exact ExternalSecret spec. The name carries a hash of the spec Helm renders, so the
secrets volume, whose items name the key, cannot mount for a pod while the Secret still
holds what ESO synced from an older spec -- a remapped key that already exists would otherwise pass.
A value changed only in BWS leaves the spec, and so the name, unchanged.
*/}}
{{- define "oauth2-redirector.esoSyncedKey" -}}
B6P_ESO_SYNCED_{{ dict "store" .Values.externalSecrets.secretStoreRef "data" .Values.externalSecrets.data | toJson | sha256sum | trunc 12 }}
{{- end -}}

{{/*
Name of the Secret mounted at /var/lib/bluestep/secrets. With External Secrets it is always the
ExternalSecret's target; without, an operator-supplied .Values.secrets.existingSecret wins over the
inline Secret this chart renders. The app reads each key as a file of the same name and follows the
mount live, so a key the Secret lacks is simply unset.
*/}}
{{- define "oauth2-redirector.secretName" -}}
{{- if .Values.externalSecrets.enabled }}
{{- include "oauth2-redirector.fullname" . }}
{{- else }}
{{- .Values.secrets.existingSecret | default (include "oauth2-redirector.fullname" .) }}
{{- end }}
{{- end -}}

{{/*
Name of the ConfigMap holding the JVM trust settings (jvmSecurity.*). Reloader watches it by this
name, so an out-of-band edit rolls the pods. Only the jvm-security init container reads it.
*/}}
{{- define "oauth2-redirector.jvmSecurityName" -}}
{{- printf "%s-jvm-security" (include "oauth2-redirector.jvmSecurityBase" .) }}
{{- end -}}

{{/*
The fullname cut short enough that "<base>-jvm-security-local" fits in 63 characters. The suffix is
reserved before truncating, so a long fullname can't swallow it and the two names stay distinct. A
fullname of 44 characters or fewer is used unchanged.
*/}}
{{- define "oauth2-redirector.jvmSecurityBase" -}}
{{- include "oauth2-redirector.fullname" . | trunc (sub 63 (len "-jvm-security-local") | int) | trimSuffix "-" }}
{{- end -}}

{{/*
Name of the operator's optional overlay ConfigMap. Helm never renders it, so an emergency edit made
there survives deploys; the jvm-security init container merges it over the chart's.
*/}}
{{- define "oauth2-redirector.jvmSecurityLocalName" -}}
{{- printf "%s-jvm-security-local" (include "oauth2-redirector.jvmSecurityBase" .) }}
{{- end -}}
