#!/bin/bash
set -e
cd $(dirname ${0})
helm dependency update
helm package . -d ../../charts
helm repo index ../../charts